def makechar(name,outstream):
    outstream.write("define "+ name + " = Character(\"" + name + "\", image=\"pro\")\n" )
def makecharnar(name,outstream):
        outstream.write("define e = Character(\"\", image=\"pro\")\n" )
def doscene(scene,letter,outstream):
    outstream.write("#" + scene + letter +"\n")
    lastscene = " "
    curindent = "    "
    scenes =[]
    f2 = open("scenes.txt","r")
    for x in f2:
        scenes.append(x[:-1].lower())
    f = open(scene + ".txt", "r")
    initalstatement = curindent + "if curscene == \"" + letter + "\":\n"
    outstream.write(initalstatement)
    curindent += curindent
    lastchar = ""
    lastcharright = ""
    menulines = ""
    #print(scenes)
    for x in f:
        a = x.find(":")
        b = x.find("(")
        hasor = x.find("OR");
        out = curindent
        if hasor != -1 :
            menulines = x
            out += "menu:"
            curindent += "    "
           # print(out)
            #print("#" + scene + letter +"\n")
        elif x == "{\n":
            curindent += "    "
            out += "\""
            out += menulines[0:menulines.find("OR")];
            out += "\""
            if menulines.find("OR") != -1 :
                menulines = menulines[menulines.find("OR")+2:]
            else:
                menulines = "placeholderthingy"
            print(menulines)
            out += ":"
        elif x == "}\n":
            curindent = curindent[:-4]
            if menulines == "placeholderthingy":
                curindent = curindent[:-4]
            continue
        elif x[:-1].lower() in scenes:
            lastchar = ""
            lastcharright = ""
            out = curindent + "scene " + x[:-1].lower()
        elif a != -1 and (b == -1 or b > a) and a < 20:
            if x[0:a] != "???":
                out += x[0:a] + " \"" + x[a+1:-1] +"\""
            else:
                out += "unknownchar" + " \"" + x[a+1:-1] +"\""
            if x[0:a] != "Pro" and x[0:a] != "Direction" and x[0:a]!= "???":
                if lastchar != x[0:a] and lastchar != "" and lastcharright != x[0:a]:
                    outstream.write(curindent + "show " + x[0:a].lower() + " at right \n")
                    lastcharright = x[0:a]  
                elif lastchar != x[0:a] and lastcharright != x[0:a]:
                    outstream.write(curindent + "show " + x[0:a].lower() + " at left \n")
                    lastchar = x[0:a]   
        else:
            out += "e " + "\"" + x[:-1] + "\""
        out += "\n"
        outstream.write(out)
f3 = open("todoscenes.txt","r")
f4 = open("charlist.txt","r")
open('script.txt', 'w').close()
aa = open("script.txt", "a")
makecharnar("e",aa)
for x in f4:
    makechar(x[:-1],aa)
aa.write("label start:\n")
aa.write("    $curscene = \"a\"\n")
for x in f3:
   # print(x.split()[0])
    doscene(x.split()[0],x.split()[1],aa)
aa.write("    return")
aa.close()
